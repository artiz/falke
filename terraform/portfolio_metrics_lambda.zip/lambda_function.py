import json, os, boto3

cloudwatch = boto3.client("cloudwatch")
PROJECT_NAME = os.environ["PROJECT_NAME"]

def lambda_handler(event, context):
    for record in event.get("Records", []):
        if record.get("eventName") not in ("INSERT", "MODIFY"):
            continue

        new_image = record.get("dynamodb", {}).get("NewImage", {})
        if not new_image:
            continue

        # DynamoDB Number type
        user_id = int(new_image.get("user_id", {}).get("N", "0"))
        # Skip test sessions (negative user IDs) and zero
        if user_id <= 0:
            continue

        portfolio_json_str = new_image.get("portfolio_json", {}).get("S", "")
        if not portfolio_json_str:
            continue

        # Trading mode stored as a top-level attribute alongside portfolio_json
        mode = new_image.get("mode", {}).get("S", "paper")

        try:
            portfolio = json.loads(portfolio_json_str)
        except Exception:
            continue

        # Rust Decimal serialises as a string, e.g. "123.45"
        cash = float(portfolio.get("balance", "0") or 0)

        positions_value = 0.0
        for pos in portfolio.get("open_positions", {}).values():
            price = float(pos.get("current_price", "0") or 0)
            qty   = float(pos.get("quantity", "0") or 0)
            positions_value += price * qty

        total_value = cash + positions_value

        dimensions = [
            {"Name": "Project", "Value": PROJECT_NAME},
            {"Name": "Mode", "Value": mode},
        ]

        cloudwatch.put_metric_data(
            Namespace="Falke/Portfolio",
            MetricData=[
                {
                    "MetricName": "CashBalance",
                    "Dimensions": dimensions,
                    "Value": cash,
                    "Unit": "None",
                },
                {
                    "MetricName": "TotalValue",
                    "Dimensions": dimensions,
                    "Value": total_value,
                    "Unit": "None",
                },
            ],
        )
